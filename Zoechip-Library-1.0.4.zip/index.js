(function () {
  'use strict';
  var BASE = 'https://zoechip.bz';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';
  var AJAX = { Referer: BASE + '/', 'X-Requested-With': 'XMLHttpRequest' };

  function decode(value) {
    return String(value || '').replace(/&amp;/gi, '&').replace(/&quot;/gi, '"')
      .replace(/&#0*39;|&apos;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
      .replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(Number(n)); })
      .replace(/&#x([0-9a-f]+);/gi, function (_, n) { return String.fromCharCode(parseInt(n, 16)); });
  }
  function clean(value) { return decode(String(value || '').replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim(); }
  function attr(tag, name) {
    var match = String(tag || '').match(new RegExp('(?:^|\\s)' + name + '\\s*=\\s*(["\'])([\\s\\S]*?)\\1', 'i'));
    return match ? decode(match[2]) : '';
  }
  function absolute(value) {
    value = decode(value);
    if (/^https:\/\/[^\s"'<>]+$/i.test(value)) return value;
    if (value.slice(0, 2) === '//') return 'https:' + value;
    if (value.charAt(0) === '/') return BASE + value;
    return '';
  }
  function itemInfo(value) {
    var url = absolute(String(value || '').split('#')[0].split('?')[0]).replace(/\/$/, '');
    var m = url.match(/^https:\/\/zoechip\.bz\/(movie|tv)\/[a-z0-9-]+-([a-z0-9]+)$/i);
    if (!m) throw new Error('Invalid Zoechip movie or TV URL');
    return { url: url, type: m[1].toLowerCase(), id: m[2] };
  }
  async function read(url, headers, wantJson) {
    if (typeof fetchv2 !== 'function') throw new Error('Player fetchv2 is unavailable');
    var requestHeaders = { 'User-Agent': UA };
    Object.keys(headers || {}).forEach(function (key) { requestHeaders[key] = headers[key]; });
    var response = await fetchv2(url, requestHeaders, 'GET', null);
    if (!response) throw new Error('Empty response from source');
    var status = typeof response.status === 'number' ? response.status : response.statusCode;
    if (typeof status === 'number' && (status < 200 || status >= 300)) throw new Error('Source returned HTTP ' + status);
    var data;
    if (wantJson && typeof response.json === 'function') { try { data = await response.json(); } catch (_) {} }
    else if (wantJson && response.json != null) data = response.json;
    if ((data === undefined || data === null || data === '') && typeof response.text === 'function') { try { data = await response.text(); } catch (_) {} }
    else if ((data === undefined || data === null || data === '') && typeof response.text === 'string') data = response.text;
    if ((data === undefined || data === null || data === '') && response.body != null) data = response.body;
    if (wantJson && typeof data === 'string') { try { data = JSON.parse(data); } catch (_) { throw new Error('Source returned invalid JSON'); } }
    if (wantJson && (!data || typeof data !== 'object' || Array.isArray(data))) throw new Error('Source returned an unexpected JSON response');
    if (!wantJson && typeof data !== 'string') throw new Error('Source returned an unexpected text response');
    return data;
  }
  async function readGuts(url, headers, wantJson) {
    try { return await read(url, headers, wantJson); }
    catch (error) {
      // Retry only a transient gateway error, never access-denied responses.
      if (!/HTTP 50[234]\b/.test(String(error && error.message || error))) throw error;
      return await read(url, headers, wantJson);
    }
  }
  function anchors(html, className) {
    var re = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi, match, result = [];
    while ((match = re.exec(html))) {
      var tag = match[1], classes = ' ' + attr(tag, 'class').replace(/\s+/g, ' ') + ' ';
      if (classes.indexOf(' ' + className + ' ') !== -1) result.push({ tag: tag, text: clean(match[2]) });
    }
    return result;
  }

  function parseCards(html, limit) {
    var cards = html.split(/<div\s+class=["']flw-item["'][^>]*>/i), result = [], seen = {};
    for (var i = 1; i < cards.length && result.length < limit; i++) {
      var links = anchors(cards[i], 'film-poster-ahref');
      if (!links.length) continue;
      var href = absolute(attr(links[0].tag, 'href')), title = clean(attr(links[0].tag, 'title'));
      var imageTag = cards[i].match(/<img\b[^>]*>/i), image = imageTag ? absolute(attr(imageTag[0], 'data-src') || attr(imageTag[0], 'src')) : '';
      try { itemInfo(href); } catch (_) { continue; }
      if (title && !seen[href]) { seen[href] = true; result.push({ title: title, href: href, id: href, image: image }); }
    }
    return result;
  }
  globalThis.searchResults = async function (query) {
    var text = String(query || '').trim();
    if (!text) return [];
    var slug = text.replace(/['"]/g, '').replace(/\s+/g, '-').toLowerCase();
    var html = await read(BASE + '/search/' + encodeURIComponent(slug) + '?page=1', {}, false);
    var results = parseCards(html, 30), seen = {};
    results.forEach(function (item) { seen[item.href] = true; });
    // Video search has no documented pagination callback. Read up to three
    // live source pages while the site advertises another page; discovery feeds
    // remain paginated independently for browsing the full available catalogue.
    for (var page = 2; page <= 3 && /<a\b[^>]*\btitle=["']Next["'][^>]*>/i.test(html); page++) {
      html = await read(BASE + '/search/' + encodeURIComponent(slug) + '?page=' + page, {}, false);
      parseCards(html, 30).forEach(function (item) { if (!seen[item.href]) { seen[item.href] = true; results.push(item); } });
    }
    return results;
  };

  globalThis.discoveryHome = async function () {
    var html = await read(BASE + '/home', {}, false), blocks = html.match(/<section\b[^>]*>[\s\S]*?<\/section>/gi) || [];
    var listingPages = await Promise.all(['/movie?page=1', '/tv-show?page=1'].map(async function (path) {
      try { return await read(BASE + path, {}, false); } catch (_) { return ''; }
    }));
    var definitions = [
      { heading: 'Trending', id: 'trending', style: 'hero', limit: 8 },
      { heading: 'Latest Movies', title: 'All Movies', id: 'movies', style: 'poster', limit: 30, listing: 0 },
      { heading: 'Latest TV Shows', title: 'All TV Shows', id: 'tv', style: 'poster', limit: 30, listing: 1 }
    ];
    var sections = [];
    definitions.forEach(function (definition) {
      var block = blocks.find(function (value) {
        var heading = value.match(/<h2\b[^>]*class=["'][^"']*\bcat-heading\b[^"']*["'][^>]*>([\s\S]*?)<\/h2>/i);
        return heading && clean(heading[1]) === definition.heading;
      });
      var listing = definition.listing == null ? '' : listingPages[definition.listing];
      var items = listing ? parseCards(listing, definition.limit) : block ? parseCards(block, definition.limit) : [];
      if (definition.id === 'movies') items = items.filter(function (item) { return /\/movie\//.test(item.href); });
      if (definition.id === 'tv') items = items.filter(function (item) { return /\/tv\//.test(item.href); });
      if (!items.length) return;
      var section = { id: definition.id, title: definition.title || definition.heading, style: definition.style, items: items };
      if (definition.id !== 'trending') section.viewAll = { mode: 'feed', feedId: definition.id };
      sections.push(section);
    });
    if (!sections.length) throw new Error('Zoechip home page did not return any titles');
    return { sections: sections };
  };
  globalThis.discoveryFeed = async function (feedId, page) {
    var path = feedId === 'movies' ? '/movie' : feedId === 'tv' ? '/tv-show' : '';
    if (!path) throw new Error('Unknown Zoechip feed');
    var index = Number(page);
    if (!isFinite(index) || index < 1 || Math.floor(index) !== index || index > 100000) throw new Error('Invalid page number');
    var html = await read(BASE + path + '?page=' + index, {}, false);
    var items = parseCards(html, 50).filter(function (item) { return feedId === 'movies' ? /\/movie\//.test(item.href) : /\/tv\//.test(item.href); });
    return { items: items, page: index, hasMore: /<a\b[^>]*\btitle=["']Next["'][^>]*>/i.test(html) };
  };

  globalThis.extractDetails = async function (urlOrId) {
    var item = itemInfo(urlOrId), html = await read(item.url, {}, false);
    var heading = html.match(/<h[1-3]\b[^>]*class=["'][^"']*heading-name[^"']*["'][^>]*>([\s\S]*?)<\/h[1-3]>/i);
    var description = html.match(/<div\b[^>]*class=["'][^"']*\bdescription\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i);
    var poster = html.match(/<img\b[^>]*data-show-poster=["'][^"']+["'][^>]*>/i);
    var title = heading ? clean(heading[1]) : '';
    if (!title) throw new Error('Zoechip did not return show details');
    return { title: title, description: description ? clean(description[1]) : '', image: poster ? absolute(attr(poster[0], 'data-show-poster')) : '', id: item.url, href: item.url };
  };

  globalThis.extractEpisodes = async function (seriesId) {
    var item = itemInfo(seriesId);
    if (item.type === 'movie') return [{ number: 1, title: 'Movie', href: BASE + '/ajax/episode/list/' + item.id, subAvailable: true, dubAvailable: false }];
    // These exact titles and episode listings were compared against Guts.
    // No other title is silently mapped to an alternate source.
    var gutsId = item.id === 'y3neT1w9x9g' ? '79698' : item.id === 'vLXwLu68xD5P' ? '82818' : item.id === 'dO4nI71XBB' ? '79702' : '';
    var gutsEpisodes = null, observedSeasons = [];
    if (gutsId) {
      try { gutsEpisodes = await readGuts('https://guts.to/ajax/v2/episode/list/' + gutsId, { Referer: 'https://guts.to/', 'X-Requested-With': 'XMLHttpRequest' }, true); }
      catch (_) { gutsEpisodes = null; }
    }
    var html = await read(BASE + '/ajax/season/list/' + item.id, AJAX, false);
    var seasons = anchors(html, 'ss-item');
    if (!seasons.length) throw new Error('Zoechip did not return any seasons');
    var episodes = [];
    for (var i = 0; i < seasons.length; i += 3) {
      var batch = seasons.slice(i, i + 3);
      var pages = await Promise.all(batch.map(function (season) {
        var id = attr(season.tag, 'data-id');
        if (!/^[a-z0-9]+$/i.test(id)) throw new Error('Invalid season identifier');
        return read(BASE + '/ajax/season/episodes/' + id, AJAX, false);
      }));
      for (var j = 0; j < pages.length; j++) {
        var seasonName = batch[j].text || 'Season';
        var seasonNum = (seasonName.match(/\d+/) || [])[0];
        var entries = anchors(pages[j], 'eps-item');
        var seasonValid = true;
        for (var k = 0; k < entries.length; k++) {
          var id = attr(entries[k].tag, 'data-id'), fullTitle = attr(entries[k].tag, 'title') || entries[k].text;
          var n = fullTitle.match(/(?:Eps?|Episode)\s*(\d+)/i);
          if (!/^[a-z0-9]+$/i.test(id) || !n) { seasonValid = false; continue; }
          var number = Number(n[1]), name = clean(fullTitle.replace(/^(?:Eps?|Episode)\s*\d+\s*:?\s*/i, ''));
          if (number !== k + 1) seasonValid = false;
          var episode = { number: number, title: seasonName + ' · Episode ' + number + (name ? ': ' + name : ''), href: BASE + '/ajax/episode/servers/' + id, subAvailable: true, dubAvailable: false };
          if (seasonNum) episode.season = Number(seasonNum);
          episodes.push(episode);
        }
        observedSeasons.push({ name: seasonName, count: entries.length, valid: seasonValid });
      }
    }
    if (!episodes.length) throw new Error('Zoechip did not return any episodes');
    var expectedSagaNames = ['Saiyan Saga', 'Namek Saga', 'Frieza Saga', 'Androids Saga', 'Cell Saga', 'Cell Games Saga', 'World Tournament Saga', 'Majin Buu Saga', 'Kid Buu Saga'];
    var expectedSagaCounts = [39, 35, 33, 32, 26, 29, 25, 34, 38];
    var zMappingSafe = gutsId === '79702' && episodes.length === 291 && observedSeasons.length === expectedSagaNames.length && observedSeasons.every(function (s, i) { return s.valid && s.name === expectedSagaNames[i] && s.count === expectedSagaCounts[i]; });
    var singleSeasonSafe = gutsId !== '79702' && observedSeasons.length === 1 && observedSeasons[0].valid && observedSeasons[0].name === 'Season 1';
    if (gutsEpisodes && gutsEpisodes.status && (zMappingSafe || singleSeasonSafe)) {
      episodes.forEach(function (episode, index) {
        var globalNumber = zMappingSafe ? index + 1 : episode.number;
        var sub = Array.isArray(gutsEpisodes.episodes) && gutsEpisodes.episodes.some(function (n) { return Number(n) === globalNumber; });
        var dub = Array.isArray(gutsEpisodes.dubEpisodes) && gutsEpisodes.dubEpisodes.some(function (n) { return Number(n) === globalNumber; });
        if (sub || dub) { episode.href += '?guts=' + gutsId + '&ep=' + globalNumber; episode.dubAvailable = !!dub; }
      });
    }
    return episodes;
  };

  async function vix(url) {
    var match = String(url).match(/^https:\/\/vixsrc\.to\/(movie\/\d+|tv\/\d+\/\d+\/\d+)(?:\?[^#]*)?$/i);
    if (!match) throw new Error('Unrecognized VixCloud address');
    var api = await read('https://vixsrc.to/api/' + match[1], { Referer: url }, true);
    var path = String(api.src || '');
    if (!/^\/embed\/\d+\?[^\s"'<>]+$/i.test(path)) throw new Error('VixCloud has no video for this episode');
    var embed = 'https://vixsrc.to' + path;
    var html = await read(embed, { Referer: url }, false);
    var raw = html.match(/window\.streams\s*=\s*(\[[\s\S]*?\]);/);
    if (!raw) throw new Error('VixCloud did not provide streams');
    var list; try { list = JSON.parse(raw[1]); } catch (_) { throw new Error('Invalid VixCloud stream list'); }
    var master = html.split('window.masterPlaylist')[1];
    if (!Array.isArray(list) || !master) throw new Error('Incomplete VixCloud player response');
    master = master.split('window.canPlayFHD')[0];
    var tok = master.match(/["']token["']\s*:\s*["']([^"']+)["']/), exp = master.match(/["']expires["']\s*:\s*["'](\d+)["']/);
    if (!tok || !exp) throw new Error('VixCloud stream details are missing');
    for (var i = 0; i < list.length && i < 2; i++) {
      var playlist = String(list[i] && list[i].url || '');
      if (!/^https:\/\/vixsrc\.to\/playlist\/[^\s"'<>]+$/i.test(playlist)) continue;
      // VixCloud defaults to Italian for some titles; its documented lang
      // parameter selects English as the HLS default when English exists.
      playlist += (playlist.indexOf('?') >= 0 ? '&' : '?') + 'token=' + encodeURIComponent(tok[1]) + '&expires=' + exp[1] + '&h=1&lang=en';
      try {
        var body = await read(playlist, { Referer: embed }, false);
        if (/^\s*#EXTM3U(?:\s|$)/.test(body)) return { streams: ['VixCloud Auto', playlist], headers: { Referer: embed, 'User-Agent': UA }, streamType: 'hls' };
      } catch (_) {}
    }
    throw new Error('VixCloud did not return a playable HLS playlist');
  }
  async function vidSpark(url) {
    var match = String(url).match(/^https:\/\/moviesapi\.to\/(movie\/\d+|tv\/\d+\/\d+\/\d+)(?:\?[^#]*)?$/i);
    if (!match) throw new Error('Unrecognized alternate provider');
    var player = 'https://vidspark.to/' + match[1], html = await read(player, { Referer: BASE + '/' }, false);
    var script = html.match(/<script\b[^>]*src=["'](\/assets\/index-[a-z0-9_-]+\.js)["'][^>]*>/i);
    if (!script) throw new Error('Alternate video player unavailable');
    var code = await read('https://vidspark.to' + script[1], { Referer: player }, false);
    var key = code.match(/(?:var|let|const)\s+[\w$]+=`([a-f0-9]{64})`/);
    if (!key) throw new Error('Alternate video player configuration unavailable');
    var payload = await read('https://vidspark.to/api/vidora/v1/' + match[1], { Referer: player, 'x-player-key': key[1] }, true);
    if (!payload.result || !Array.isArray(payload.sources)) throw new Error('Alternate provider has no video for this episode');
    for (var i = 0; i < payload.sources.length && i < 3; i++) {
      var media = String(payload.sources[i] && payload.sources[i].url || '');
      if (!/^https:\/\/[^\s"'<>]+$/i.test(media)) continue;
      try {
        var body = await read(media, { Referer: 'https://vidspark.to/' }, false);
        if (/^\s*#EXTM3U(?:\s|$)/.test(body)) return { streams: ['VidSpark Auto', media], headers: { Referer: 'https://vidspark.to/', 'User-Agent': UA }, streamType: 'hls' };
      } catch (_) {}
    }
    throw new Error('Alternate provider did not return a playable HLS playlist');
  }
  async function gutsDragonBall(gutsId, episodeNumber, lang) {
    var audio = String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub';
    var referer = 'https://guts.to/';
    var ajax = { Referer: referer, 'X-Requested-With': 'XMLHttpRequest' };
    // The episode list already confirmed availability. Recheck the requested
    // audio against the live server list below instead of fetching the list twice.
    var servers = await readGuts(referer + 'ajax/v2/episode/servers?episodeId=' + episodeNumber + '&mov_id=' + gutsId, ajax, true);
    if (!servers.status || !Array.isArray(servers.html)) throw new Error('Guts did not return episode servers');
    var tags = servers.html.join(' ').match(/<div\b[^>]*server-item[^>]*>/gi) || [];
    var tag = tags.find(function (t) { return attr(t, 'data-type') === audio && attr(t, 'data-server-id') === '4'; });
    var id = tag ? attr(tag, 'data-id') : '';
    if (!/^[a-f0-9]+$/i.test(id)) throw new Error('Guts has no server for the selected audio');
    var source = await readGuts(referer + 'ajax/v2/episode/sources?id=' + encodeURIComponent(id), ajax, true);
    var embed = String(source.link || '');
    if (!/^https:\/\/play\.vhscdn\.to\/embed-1\/[a-z0-9]+(?:\?[^#]*)?$/i.test(embed)) throw new Error('Guts returned an unsupported video player');
    var player = await read(embed, { Referer: referer }, false);
    var screen = (player.match(/<[^>]*id=["']screen["'][^>]*>/i) || [])[0] || '';
    var sourceId = attr(screen, 'data-id');
    if (!/^[a-z0-9]+$/i.test(sourceId)) throw new Error('Guts video player is missing its source');
    var data = await read('https://play.vhscdn.to/embed-1/getSources?id=' + encodeURIComponent(sourceId), { Referer: embed }, true);
    var sources = data.sources, media = typeof sources === 'string' ? sources : '';
    if (Array.isArray(sources) && sources.length) media = typeof sources[0] === 'string' ? sources[0] : String(sources[0].file || sources[0].src || '');
    if (!/^https:\/\/[^\s"'<>]+$/i.test(media)) throw new Error('Guts returned no video source');
    var headers = { Referer: 'https://play.vhscdn.to/', 'User-Agent': UA };
    var playlist = await read(media, headers, false);
    if (!/^\s*#EXTM3U(?:\s|$)/.test(playlist)) throw new Error('Guts did not return a video playlist');
    var subtitles = [];
    if (Array.isArray(data.tracks)) data.tracks.forEach(function (track) {
      var url = String(track && track.file || ''), kind = String(track && track.kind || '').toLowerCase();
      if ((kind === 'captions' || kind === 'subtitles') && /^https:\/\/[^\s"'<>]+$/i.test(url)) subtitles.push({ url: url, file: url, label: String(track.label || 'Subtitle'), kind: 'subtitle', headers: headers });
    });
    return { streams: ['Guts ' + audio.toUpperCase(), media], headers: headers, streamType: 'hls', subtitles: subtitles };
  }
  globalThis.extractStreamUrl = async function (episodeHref, lang) {
    var url = String(episodeHref || ''), match = url.match(/^https:\/\/zoechip\.bz\/ajax\/episode\/(servers|list)\/([a-z0-9]+)(?:\?guts=(79698|82818|79702)&ep=(\d+))?$/i);
    if (!match) throw new Error('Invalid Zoechip episode address');
    if (match[3]) return await gutsDragonBall(match[3], Number(match[4]), lang);
    var html = await read(url, AJAX, false), all = anchors(html, 'link-item');
    var desired = all.filter(function (server) { return /VixCloud|MegaCloud/i.test(attr(server.tag, 'title')); });
    desired.sort(function (a, b) { return (/VixCloud/i.test(attr(a.tag, 'title')) ? 0 : 1) - (/VixCloud/i.test(attr(b.tag, 'title')) ? 0 : 1); });
    for (var i = 0; i < desired.length; i++) {
      var id = attr(desired[i].tag, 'data-id');
      if (!/^[a-z0-9]+$/i.test(id)) continue;
      try {
        var source = await read(BASE + '/ajax/episode/sources/' + id, AJAX, true);
        if (/VixCloud/i.test(attr(desired[i].tag, 'title'))) return await vix(source.link);
        if (/MegaCloud/i.test(attr(desired[i].tag, 'title'))) return await vidSpark(source.link);
      } catch (_) {}
    }
    throw new Error('No supported playable video was found for this episode');
  };
})();
