(function () {
  'use strict';
  var BASE = 'https://zoechip.bz';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';
  var AJAX = { Referer: BASE + '/', 'X-Requested-With': 'XMLHttpRequest' };

  function decode(value) {
    return String(value || '').replace(/&amp;/gi, '&').replace(/&quot;/gi, '"')
      .replace(/&#0*39;|&apos;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
      .replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(Number(n)); })
      .replace(/&#x([0-9a-f]+);/gi, function (_, n) { return String.fromCharCode(parseInt(n, 16)); });
  }
  function clean(value) { return decode(String(value || '').replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim(); }
  function attr(tag, name) {
    var match = String(tag || '').match(new RegExp('(?:^|\\s)' + name + '\\s*=\\s*(["\'])([\\s\\S]*?)\\1', 'i'));
    return match ? decode(match[2]) : '';
  }
  function absolute(value) {
    value = decode(value);
    if (/^https:\/\/[^\s"'<>]+$/i.test(value)) return value;
    if (value.slice(0, 2) === '//') return 'https:' + value;
    if (value.charAt(0) === '/') return BASE + value;
    return '';
  }
  function itemInfo(value) {
    var url = absolute(String(value || '').split('#')[0].split('?')[0]).replace(/\/$/, '');
    var m = url.match(/^https:\/\/zoechip\.bz\/(movie|tv)\/[a-z0-9-]+-([a-z0-9]+)$/i);
    if (!m) throw new Error('Invalid Zoechip movie or TV URL');
    return { url: url, type: m[1].toLowerCase(), id: m[2] };
  }
  async function read(url, headers, wantJson) {
    if (typeof fetchv2 !== 'function') throw new Error('Player fetchv2 is unavailable');
    var requestHeaders = { 'User-Agent': UA };
    Object.keys(headers || {}).forEach(function (key) { requestHeaders[key] = headers[key]; });
    var response = await fetchv2(url, requestHeaders, 'GET', null);
    if (!response) throw new Error('Empty response from source');
    var status = typeof response.status === 'number' ? response.status : response.statusCode;
    if (typeof status === 'number' && (status < 200 || status >= 300)) throw new Error('Source returned HTTP ' + status);
    var data;
    if (wantJson && typeof response.json === 'function') { try { data = await response.json(); } catch (_) {} }
    if ((data === undefined || data === null || data === '') && typeof response.text === 'function') { try { data = await response.text(); } catch (_) {} }
    if ((data === undefined || data === null || data === '') && response.body != null) data = response.body;
    if (wantJson && typeof data === 'string') { try { data = JSON.parse(data); } catch (_) { throw new Error('Source returned invalid JSON'); } }
    if (wantJson && (!data || typeof data !== 'object' || Array.isArray(data))) throw new Error('Source returned an unexpected JSON response');
    if (!wantJson && typeof data !== 'string') throw new Error('Source returned an unexpected text response');
    return data;
  }
  function anchors(html, className) {
    var re = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi, match, result = [];
    while ((match = re.exec(html))) {
      var tag = match[1], classes = ' ' + attr(tag, 'class').replace(/\s+/g, ' ') + ' ';
      if (classes.indexOf(' ' + className + ' ') !== -1) result.push({ tag: tag, text: clean(match[2]) });
    }
    return result;
  }

  function parseCards(html, limit) {
    var cards = html.split(/<div\s+class=["']flw-item["'][^>]*>/i), result = [], seen = {};
    for (var i = 1; i < cards.length && result.length < limit; i++) {
      var links = anchors(cards[i], 'film-poster-ahref');
      if (!links.length) continue;
      var href = absolute(attr(links[0].tag, 'href')), title = clean(attr(links[0].tag, 'title'));
      var imageTag = cards[i].match(/<img\b[^>]*>/i), image = imageTag ? absolute(attr(imageTag[0], 'data-src') || attr(imageTag[0], 'src')) : '';
      try { itemInfo(href); } catch (_) { continue; }
      if (title && !seen[href]) { seen[href] = true; result.push({ title: title, href: href, id: href, image: image }); }
    }
    return result;
  }
  globalThis.searchResults = async function (query) {
    var text = String(query || '').trim();
    if (!text) return [];
    var slug = text.replace(/['"]/g, '').replace(/\s+/g, '-').toLowerCase();
    var html = await read(BASE + '/search/' + encodeURIComponent(slug) + '?page=1', {}, false);
    return parseCards(html, 30);
  };

  globalThis.discoveryHome = async function () {
    var html = await read(BASE + '/home', {}, false), blocks = html.match(/<section\b[^>]*>[\s\S]*?<\/section>/gi) || [];
    var definitions = [
      { heading: 'Trending', id: 'trending', style: 'hero', limit: 8 },
      { heading: 'Latest Movies', id: 'movies', style: 'poster', limit: 30 },
      { heading: 'Latest TV Shows', id: 'tv', style: 'poster', limit: 30 }
    ];
    var sections = [];
    definitions.forEach(function (definition) {
      var block = blocks.find(function (value) {
        var heading = value.match(/<h2\b[^>]*class=["'][^"']*\bcat-heading\b[^"']*["'][^>]*>([\s\S]*?)<\/h2>/i);
        return heading && clean(heading[1]) === definition.heading;
      });
      var items = block ? parseCards(block, definition.limit) : [];
      if (!items.length) return;
      var section = { id: definition.id, title: definition.heading, style: definition.style, items: items };
      if (definition.id !== 'trending') section.viewAll = { mode: 'feed', feedId: definition.id };
      sections.push(section);
    });
    if (!sections.length) throw new Error('Zoechip home page did not return any titles');
    return { sections: sections };
  };
  globalThis.discoveryFeed = async function (feedId, page) {
    var path = feedId === 'movies' ? '/movie' : feedId === 'tv' ? '/tv-show' : '';
    if (!path) throw new Error('Unknown Zoechip feed');
    var index = Number(page);
    if (!isFinite(index) || index < 1 || Math.floor(index) !== index || index > 100000) throw new Error('Invalid page number');
    var html = await read(BASE + path + '?page=' + index, {}, false);
    return { items: parseCards(html, 50), page: index, hasMore: /<a\b[^>]*\btitle=["']Next["'][^>]*>/i.test(html) };
  };

  globalThis.extractDetails = async function (urlOrId) {
    var item = itemInfo(urlOrId), html = await read(item.url, {}, false);
    var heading = html.match(/<h[1-3]\b[^>]*class=["'][^"']*heading-name[^"']*["'][^>]*>([\s\S]*?)<\/h[1-3]>/i);
    var description = html.match(/<div\b[^>]*class=["'][^"']*\bdescription\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i);
    var poster = html.match(/<img\b[^>]*data-show-poster=["'][^"']+["'][^>]*>/i);
    var title = heading ? clean(heading[1]) : '';
    if (!title) throw new Error('Zoechip did not return show details');
    return { title: title, description: description ? clean(description[1]) : '', image: poster ? absolute(attr(poster[0], 'data-show-poster')) : '', id: item.url, href: item.url };
  };

  globalThis.extractEpisodes = async function (seriesId) {
    var item = itemInfo(seriesId);
    if (item.type === 'movie') return [{ number: 1, title: 'Movie', href: BASE + '/ajax/episode/list/' + item.id, subAvailable: true, dubAvailable: false }];
    var html = await read(BASE + '/ajax/season/list/' + item.id, AJAX, false);
    var seasons = anchors(html, 'ss-item');
    if (!seasons.length) throw new Error('Zoechip did not return any seasons');
    var episodes = [];
    for (var i = 0; i < seasons.length; i += 3) {
      var batch = seasons.slice(i, i + 3);
      var pages = await Promise.all(batch.map(function (season) {
        var id = attr(season.tag, 'data-id');
        if (!/^[a-z0-9]+$/i.test(id)) throw new Error('Invalid season identifier');
        return read(BASE + '/ajax/season/episodes/' + id, AJAX, false);
      }));
      for (var j = 0; j < pages.length; j++) {
        var seasonName = batch[j].text || 'Season';
        var seasonNum = (seasonName.match(/\d+/) || [])[0];
        var entries = anchors(pages[j], 'eps-item');
        for (var k = 0; k < entries.length; k++) {
          var id = attr(entries[k].tag, 'data-id'), fullTitle = attr(entries[k].tag, 'title') || entries[k].text;
          var n = fullTitle.match(/(?:Eps?|Episode)\s*(\d+)/i);
          if (!/^[a-z0-9]+$/i.test(id) || !n) continue;
          var number = Number(n[1]), name = clean(fullTitle.replace(/^(?:Eps?|Episode)\s*\d+\s*:?\s*/i, ''));
          var episode = { number: number, title: seasonName + ' · Episode ' + number + (name ? ': ' + name : ''), href: BASE + '/ajax/episode/servers/' + id, subAvailable: true, dubAvailable: false };
          if (seasonNum) episode.season = Number(seasonNum);
          episodes.push(episode);
        }
      }
    }
    if (!episodes.length) throw new Error('Zoechip did not return any episodes');
    return episodes;
  };

  async function vix(url) {
    var match = String(url).match(/^https:\/\/vixsrc\.to\/(movie\/\d+|tv\/\d+\/\d+\/\d+)(?:\?[^#]*)?$/i);
    if (!match) throw new Error('Unrecognized VixCloud address');
    var api = await read('https://vixsrc.to/api/' + match[1], { Referer: url }, true);
    var path = String(api.src || '');
    if (!/^\/embed\/\d+\?[^\s"'<>]+$/i.test(path)) throw new Error('VixCloud has no video for this episode');
    var embed = 'https://vixsrc.to' + path;
    var html = await read(embed, { Referer: url }, false);
    var raw = html.match(/window\.streams\s*=\s*(\[[\s\S]*?\]);/);
    if (!raw) throw new Error('VixCloud did not provide streams');
    var list; try { list = JSON.parse(raw[1]); } catch (_) { throw new Error('Invalid VixCloud stream list'); }
    var master = html.split('window.masterPlaylist')[1];
    if (!Array.isArray(list) || !master) throw new Error('Incomplete VixCloud player response');
    master = master.split('window.canPlayFHD')[0];
    var tok = master.match(/["']token["']\s*:\s*["']([^"']+)["']/), exp = master.match(/["']expires["']\s*:\s*["'](\d+)["']/);
    if (!tok || !exp) throw new Error('VixCloud stream details are missing');
    for (var i = 0; i < list.length && i < 2; i++) {
      var playlist = String(list[i] && list[i].url || '');
      if (!/^https:\/\/vixsrc\.to\/playlist\/[^\s"'<>]+$/i.test(playlist)) continue;
      playlist += (playlist.indexOf('?') >= 0 ? '&' : '?') + 'token=' + encodeURIComponent(tok[1]) + '&expires=' + exp[1] + '&h=1';
      try {
        var body = await read(playlist, { Referer: embed }, false);
        if (/^\s*#EXTM3U(?:\s|$)/.test(body)) return { streams: ['VixCloud Auto', playlist], headers: { Referer: embed, 'User-Agent': UA }, streamType: 'hls' };
      } catch (_) {}
    }
    throw new Error('VixCloud did not return a playable HLS playlist');
  }
  async function vidSpark(url) {
    var match = String(url).match(/^https:\/\/moviesapi\.to\/(movie\/\d+|tv\/\d+\/\d+\/\d+)(?:\?[^#]*)?$/i);
    if (!match) throw new Error('Unrecognized alternate provider');
    var player = 'https://vidspark.to/' + match[1], html = await read(player, { Referer: BASE + '/' }, false);
    var script = html.match(/<script\b[^>]*src=["'](\/assets\/index-[a-z0-9_-]+\.js)["'][^>]*>/i);
    if (!script) throw new Error('Alternate video player unavailable');
    var code = await read('https://vidspark.to' + script[1], { Referer: player }, false);
    var key = code.match(/(?:var|let|const)\s+[\w$]+=`([a-f0-9]{64})`/);
    if (!key) throw new Error('Alternate video player configuration unavailable');
    var payload = await read('https://vidspark.to/api/vidora/v1/' + match[1], { Referer: player, 'x-player-key': key[1] }, true);
    if (!payload.result || !Array.isArray(payload.sources)) throw new Error('Alternate provider has no video for this episode');
    for (var i = 0; i < payload.sources.length && i < 3; i++) {
      var media = String(payload.sources[i] && payload.sources[i].url || '');
      if (!/^https:\/\/[^\s"'<>]+$/i.test(media)) continue;
      try {
        var body = await read(media, { Referer: 'https://vidspark.to/' }, false);
        if (/^\s*#EXTM3U(?:\s|$)/.test(body)) return { streams: ['VidSpark Auto', media], headers: { Referer: 'https://vidspark.to/', 'User-Agent': UA }, streamType: 'hls' };
      } catch (_) {}
    }
    throw new Error('Alternate provider did not return a playable HLS playlist');
  }
  globalThis.extractStreamUrl = async function (episodeHref, lang) {
    var url = String(episodeHref || ''), match = url.match(/^https:\/\/zoechip\.bz\/ajax\/episode\/(servers|list)\/([a-z0-9]+)$/i);
    if (!match) throw new Error('Invalid Zoechip episode address');
    var html = await read(url, AJAX, false), all = anchors(html, 'link-item');
    var desired = all.filter(function (server) { return /VixCloud|MegaCloud/i.test(attr(server.tag, 'title')); });
    desired.sort(function (a, b) { return (/VixCloud/i.test(attr(a.tag, 'title')) ? 0 : 1) - (/VixCloud/i.test(attr(b.tag, 'title')) ? 0 : 1); });
    for (var i = 0; i < desired.length; i++) {
      var id = attr(desired[i].tag, 'data-id');
      if (!/^[a-z0-9]+$/i.test(id)) continue;
      try {
        var source = await read(BASE + '/ajax/episode/sources/' + id, AJAX, true);
        if (/VixCloud/i.test(attr(desired[i].tag, 'title'))) return await vix(source.link);
        if (/MegaCloud/i.test(attr(desired[i].tag, 'title'))) return await vidSpark(source.link);
      } catch (_) {}
    }
    throw new Error('No supported playable video was found for this episode');
  };
})();
